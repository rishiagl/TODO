﻿using System;
using System.Collections.Generic;

namespace TODO.Views
{
    internal class Menu
    {
        public static void Write(List<Option> options, Option selectedOption, string header = "header\n", string footer = "footer\n")
        {
            Console.Clear();
            Console.WriteLine("\n\n--------------------------------------");
            Console.WriteLine("        TODO Console Application      ");
            Console.WriteLine("--------------------------------------\n");

            Console.WriteLine(header);
            foreach (Option option in options)
            {
                if (option == selectedOption)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write("> ");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(" ");
                }

                Console.WriteLine(option.Name);
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(footer);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
